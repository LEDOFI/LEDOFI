<?php

define("ROOT_PATH", realpath(dirname(__FILE__)));
define("BASE_URL", "https://ledofi.000webhostapp.com");
