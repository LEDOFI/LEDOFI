<?php include("../../path.php"); ?>
<?php session_start();
require(ROOT_PATH . "/app/database/db.php");?>
<?php
if($_SESSION['role']=='admin') {
?>
<?php


$errors = array();

if (isset($_GET['delete_id'])) {
	$delete_id = $_GET['delete_id'];
	
	$sql_delete = "DELETE FROM users WHERE id='$delete_id'";
	$result = mysqli_query($conn, $sql_delete);
	
	if($result != null)
	{
		mysqli_close($conn);
		$_SESSION['message'] = 'Uživatel byl smazán';
		$_SESSION['type'] = 'success';
		header('location: ' . BASE_URL . '/admin/users/index.php');
		exit;
	}
	else
	{
		echo mysqli_error();
	}
}
?>
<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">

        <!-- Font Awesome -->
        <link rel="stylesheet"
            href="https://use.fontawesome.com/releases/v5.7.2/css/all.css"
            integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr"
            crossorigin="anonymous">

        <!-- Google Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=BioRhyme&family=Lora&display=swap" rel="stylesheet">

        <!-- Custom Styling -->
        <link rel="stylesheet" href="../../assets/css/style.css">

        <!-- Admin Styling -->
        <link rel="stylesheet" href="../../assets/css/admin.css">

        <title>Admin - Spravovat uživatele</title>
    </head>

    <body>
        
    <?php include(ROOT_PATH . "/app/includes/dashboardHeader.php"); ?>

        <!-- Admin Page Wrapper -->
        <div class="admin-wrapper">

        <?php include(ROOT_PATH . "/app/includes/dashboardSidebar.php"); ?>


            <!-- Admin Content -->
            <div class="admin-content">
                <div class="button-group">
                    <a href="create.php" class="btn btn-big">Přidat uživatele</a>
                    <a href="index.php" class="btn btn-big">Spravovat uživatele</a>
                </div>
                <div class="content">
                    <h2 class="page-title">Spravovat uživatele</h2>

                    <?php include(ROOT_PATH . "/app/includes/messages.php"); ?>

                    <table>
                        <thead>
                            <th>SČ</th>
                            <th>Uživatelské jméno</th>
                            <th>Email</th>
                            <th colspan="2">Akce</th>
                        </thead>
                        <tbody>
							<?php
								$key = 1;
								$sql = "SELECT * FROM users";
								$results = mysqli_query($conn,$sql);
								while ($user = mysqli_fetch_assoc($results)) {
							?>
                                <tr>
                                    <td><?php echo $key++; ?></td>
                                    <td><?php echo $user['username']; ?></td>
                                    <td><?php echo $user['email']; ?></td>
                                    <td><a href="edit.php?id=<?php echo $user['id']; ?>" class="edit">upravit</a></td>
                                    <td>
                                        <!--<a href="index.php?delete_id=<?php echo $user['id']; ?>" class="delete">odstranit</a>-->
                                        <a onclick="return confirm('Opravdu chcete tohoto uživatele smazat? Tuto akci nelze vrátit zpět.')" href="index.php?delete_id=<?php echo $user['id']; ?>" class="delete">odstranit</a><br>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- // Admin Content -->

        </div>
        <!-- // Page Wrapper -->



        <!-- JQuery -->
        <script
            src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <!-- Ckeditor -->
        <script
            src="https://cdn.ckeditor.com/ckeditor5/12.2.0/classic/ckeditor.js"></script>
        <!-- Custom Script -->
        <script src="../../assets/js/scripts.js"></script>

    </body>

</html>

<?php } ?>