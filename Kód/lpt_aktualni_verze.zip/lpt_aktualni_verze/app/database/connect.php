<?php

$host = 'localhost';
$user = 'root';
$pass = '';
$db_name = 'id17928260_ledofi_db';

/*
$conn = new MySQLi($host, $user, $pass, $db_name);
*/

$conn = mysqli_connect($host, $user, $pass, $db_name);
 mysqli_set_charset($spojeni, "utf8");

if ($conn->connect_error) {
    die('Chyba při spojování s databází: ' . $conn->connect_error);
}