 <!-- footer -->
 <div class="footer" style="text-align: center; padding: 20px;">
 <!-- 
    <div class="footer-content">


      <div class="footer-section contact-form">
        <h2>Kontaktujte nás</h2>
        <br>
        <form action="index.html" method="post">
          <input type="email" name="email" class="text-input contact-input" placeholder="Your email address...">
          <textarea rows="4" name="message" class="text-input contact-input" placeholder="Your message..."></textarea>
          <button type="submit" value="Odeslat" class="btn btn-big contact-btn">
            <i class="fas fa-envelope"></i>
            Send
          </button>
        </form>
      </div>


    </div>
	-->

        <b>Berte na vědomí, že celá následující stránka je pouze školní projektem - neopírá se o žádné jiné instituce kromě VŠPJ</b><br>
        <b>Copyright © 2021 - LEDOFI</b>
  </div>
  <!-- // footer -->